## steps
* make model from source
```
./configure  --disable-shared --enable-static-exec
```
* run the h5diff program
```
tools/src/h5diff/h5diff plain_model.h5 malformed.h5

```

